package com.unito.tweb.javaspringbootservertweb23;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaSpringBootServerTWeb23ApplicationTests {

	@Test
	void contextLoads() {
	}

}
