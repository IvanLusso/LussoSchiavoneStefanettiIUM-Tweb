package com.unito.tweb.javaspringbootservertweb23;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaSpringBootServerTWeb23Application {

	public static void main(String[] args) {
		SpringApplication.run(JavaSpringBootServerTWeb23Application.class, args);
	}

}
